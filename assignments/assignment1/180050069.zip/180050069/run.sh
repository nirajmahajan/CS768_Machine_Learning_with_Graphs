#!/bin/bash
python3 run.py --data $1